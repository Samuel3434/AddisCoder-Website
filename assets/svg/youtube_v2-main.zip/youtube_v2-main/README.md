# slider_1
![jAVASCRIPT (1)](https://github.com/HoanghoDev/youtube_v2/assets/110652388/ee4b1f5a-4706-4acc-8842-82bf5bfc7739)
# product_has_many_price
![product_has_many_price](https://github.com/HoanghoDev/youtube_v2/assets/110652388/221e5d75-b36c-4cb2-87f5-09f945a1c4d1)
# zoom_image_product_detail
![jAVASCRIPT (6)](https://github.com/HoanghoDev/youtube_v2/assets/110652388/75ac1f02-06c7-498f-81df-f4527ae53175)
# canvas
![jAVASCRIPT (1)](https://github.com/HoanghoDev/youtube_v2/assets/110652388/06d3632f-cb25-4445-8702-3ce4a3da7a08)
# add-to-cart-react
![jAVASCRIPT (3)](https://github.com/HoanghoDev/youtube_v2/assets/110652388/0542e5bc-cc49-41e3-ba61-7501618dceea)
# auto_slider
![jAVASCRIPT (1)](https://github.com/HoanghoDev/youtube_v2/assets/110652388/4c52c19b-f554-46cb-b6eb-0a593a5e5101)
# slider_3d
![slider_3D_using_css_only](https://github.com/HoanghoDev/youtube_v2/assets/110652388/1199db3d-ca34-4bb1-bb1b-08b12c1b9995)
# scroll_animation
![scroll_animation](https://github.com/HoanghoDev/youtube_v2/assets/110652388/321f93c7-99ab-4bb0-9471-21e912f1143b)
# 3d Rotate CSS Only
![3D_animation_css_ook](https://github.com/HoanghoDev/youtube_v2/assets/110652388/37d37bb8-6a67-4eb0-810f-ffa1a3a47acb)
